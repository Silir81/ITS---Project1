# i = 10
# if i < 15: print("i is less than 15")
#
# # ---------------------------------------------
# i = 11
# if i == 11:
#     #  First if statement
#     if i < 15:
#         print("i is smaller than 15")
#
#     # Nested - if statement
#     # Will only be executed if statement above
#     # it is true
#     if (i < 12):
#         print("i is smaller than 12 too")
#     else:
#         print("i is greater than 15")
# ---------------------------------------------
i = 1
if i == 10:
    print("i is 10")
elif i == 15:
    print("i is 15")
elif i == 20:
    print("i is 20")
else:
    print("i is not present")

